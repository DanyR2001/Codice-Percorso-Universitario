package Controller;

import Model.CustomerDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "LoadPrefs", value = "/LoadPrefs")
public class LoadPrefs extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CustomerDAO service=new CustomerDAO();
        request.setAttribute("customers", service.doRetrievePrefs());
        HttpSession session=request.getSession();
        session.setAttribute("customers", service.doRetrievePrefs());
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/results/showall.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
