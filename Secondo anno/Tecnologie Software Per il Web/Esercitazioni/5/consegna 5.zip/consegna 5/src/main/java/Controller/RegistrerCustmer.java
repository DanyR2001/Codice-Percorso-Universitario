package Controller;

import Model.Customer;
import Model.CustomerDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;

@WebServlet("/register-custmer")
public class RegistrerCustmer extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String Name = request.getParameter("Name");
        String Surname = request.getParameter("Surname");
        double balance = Double.parseDouble(request.getParameter("Balance"));
        CustomerDAO service=new CustomerDAO();
        service.doSave(new Customer(Name,Surname,balance));
        RequestDispatcher dispatcher =
                request.getRequestDispatcher("/WEB-INF/results/corret-registretion.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
