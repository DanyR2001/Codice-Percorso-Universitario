package Controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Model.CustomerDAO;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "ShowAll", value = "/ShowAll")
public class ShowAll extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CustomerDAO service=new CustomerDAO();
        request.setAttribute("customers", service.doRetrieveAll());
        HttpSession session=request.getSession();
        session.setAttribute("customers",service.doRetrieveAll());
        Integer par= (Integer) getServletContext().getAttribute("status");
        request.setAttribute("status",par);
        //System.out.println("vaule show all "+par);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/results/showall.jsp");
        dispatcher.include(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
