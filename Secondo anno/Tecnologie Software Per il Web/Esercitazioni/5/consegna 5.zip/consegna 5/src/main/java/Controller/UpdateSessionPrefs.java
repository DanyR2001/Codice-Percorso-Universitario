package Controller;

import Model.Customer;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

@WebServlet(name = "UpdateSessionPrefs", value = "/UpdateSessionPrefs")
public class UpdateSessionPrefs extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id= Integer.parseInt(request.getParameter("id"));
        String value=request.getParameter("button");
        boolean flag=false;
        if(value.equals("Aggiungi ai preferiti"))
            flag=true;
        HttpSession session=request.getSession();
        List<Customer> customers= (List<Customer>) session.getAttribute("customers");
        for (Customer cust: customers) {
            if(cust.getId()==id)
                cust.setPreference(flag);
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/results/showall.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
