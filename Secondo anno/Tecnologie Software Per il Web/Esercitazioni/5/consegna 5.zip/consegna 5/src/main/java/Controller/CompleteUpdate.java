package Controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Model.Customer;
import Model.CustomerDAO;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "CompleteUpdate", value = "/CompleteUpdate")
public class CompleteUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id=Integer.parseInt(request.getParameter("id"));
        String Name=request.getParameter("Name");
        String Surname=request.getParameter("Surname");
        Double Balance=Double.parseDouble(request.getParameter("Balance"));
        CustomerDAO service=new CustomerDAO();
        Customer compare=service.doRetrieveById(id);
        Customer input=new Customer(id,Name,Surname,Balance);
        Integer status=0;
        if(!input.equals(compare))
            status=service.doUpdateById(input);
        HttpSession session= request.getSession();
        session.setAttribute("status",status);
        //System.out.println("vaule complete "+status);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/ShowAll");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
