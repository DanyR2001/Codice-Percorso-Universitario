package Model;


public class Customer {
  private String firstName;
  private String lastName;
  private int id;
  private double balance;



  private Boolean preference;

  public Customer(String firstName, String lastName, double balance,Boolean pref) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.id = id;
    this.balance = balance;
    preference=pref;
  }

  public Customer(int id, String firstName, String lastName, double balance,Boolean pref) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.id = id;
    this.balance = balance;
    preference=pref;
  }

  public Customer(int id, String firstName, String lastName, double balance) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.id = id;
    this.balance = balance;
    preference=null;
  }

  public Customer(String firstName, String lastName, double balance) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.balance = balance;
    preference=null;
  }

  public int getId() {
    return id;
  }

  public String getFirstName() {
    return(firstName);
  }

  public String getLastName() {
    return(lastName);
  }

  public double getBalance() {
    return(balance);
  }

  public double getBalanceNoSign() {
    return((balance<0)?-balance:balance);
  }


  public void setId(int id) {
    this.id = id;
  }

  public void setBalance(double balance) {
    this.balance = balance;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public boolean equals(Customer x){
    if(this.id==x.getId())
      if(this.firstName.equals(x.getFirstName()))
        if(this.lastName.equals(x.getLastName()))
          if(this.balance==x.getBalance())
            return true;
    return false;
  }

  public Boolean getPreference() {
    return preference;
  }

  public void setPreference(Boolean preference) {
    this.preference = preference;
  }

}
  
