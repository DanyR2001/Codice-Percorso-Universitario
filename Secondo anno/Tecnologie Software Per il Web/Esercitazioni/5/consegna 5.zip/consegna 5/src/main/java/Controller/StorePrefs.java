package Controller;

import Model.Customer;
import Model.CustomerDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "StorePrefs", value = "/StorePrefs")
public class StorePrefs extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session=request.getSession();
        List<Customer> customers= (List<Customer>) session.getAttribute("customers");
        CustomerDAO service=new CustomerDAO();
        for(Customer x: customers)
            service.doUpdateById(x);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/results/showall.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
