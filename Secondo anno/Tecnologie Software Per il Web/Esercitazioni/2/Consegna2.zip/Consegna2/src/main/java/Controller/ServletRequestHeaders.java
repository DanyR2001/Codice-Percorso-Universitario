package Controller;

import Model.HeadersBean;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@WebServlet(name = "ServletRequestHeaders", value = "/index.html")
public class ServletRequestHeaders extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<String> headerName = Collections.list(request.getHeaderNames());

        HeadersBean list=new HeadersBean();

        for (int i=0;i<headerName.size();i++){
            list.add(headerName.get(i),request.getHeader(headerName.get(i)));
        }

        request.setAttribute("headers", list);

        RequestDispatcher dispatcher =
                request.getRequestDispatcher("WEB-INF/showHeaders.jsp");
        dispatcher.forward(request, response);
    }

}
