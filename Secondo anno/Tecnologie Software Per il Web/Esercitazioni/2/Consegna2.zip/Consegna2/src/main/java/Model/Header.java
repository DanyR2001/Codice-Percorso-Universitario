package Model;

public class Header {
    private String Nome;
    private String Value;

    public Header(String nome, String value) {
        Nome = nome;
        Value = value;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }
}
