package Model;

import java.util.ArrayList;

public class HeadersBean {
    private ArrayList<Header> list;

    public HeadersBean(ArrayList<Header> list){
       this.list=list;
    }

   public HeadersBean(){
        list=new ArrayList<Header>();
   }

   public void add(String Nome,String Value){
        list.add(new Header(Nome,Value));
   }

    public void add(Header x){
        list.add(x);
    }

    public ArrayList<Header> getList() {
        return list;
    }

    public void setList(ArrayList<Header> list) {
        this.list = list;
    }

    public int size(){
        return list.size();
    }

    public Header get(int i){
        return list.get(i);
    }
}
