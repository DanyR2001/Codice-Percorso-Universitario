package Controller;

import Model.Categoria;
import Model.Prodotto;
import Model.ProdottoDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "CategoriaServlet.java", value = "/CategoriaServlet.java")
public class CategoriaServletjava extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Categoria> cat= (List<Categoria>) getServletContext().getAttribute("categorie");
        int index= Integer.parseInt(request.getParameter("categoria"));
        Categoria chose=null;
        for(Categoria x: cat)
            if(x.getId()==index)
                chose=x;
        List<Prodotto> right=null;
        if(chose!=null)
            right=new ProdottoDAO().doRetrieveByCategoria(chose);
        request.setAttribute("categoria",chose);
        request.setAttribute("prodotti",right);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/results/categoria.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
