package Model;

import java.sql.*;

public class UtenteDAO {

        public static void doSave(Utente utente) {
            try (Connection con = ConPool.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO utente (username,passwordhash, email ,admin_bool) VALUES(?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, utente.getUsername());
                ps.setString(2, utente.getPasswordhash());
                ps.setString(3, utente.getEmail());
                ps.setBoolean(4, utente.isAdmin_bool());

                if (ps.executeUpdate() != 1) {
                    throw new RuntimeException("INSERT error.");
                }
                ResultSet rs = ps.getGeneratedKeys();
                rs.next();
                int id = rs.getInt(1);
                utente.setId(id);

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        public Utente doRetrieveByUsernamePassword(String user,String passw){
            try (Connection con = ConPool.getConnection()) {
                PreparedStatement ps =
                        con.prepareStatement("SELECT id, username, passwordhash, email, admin_bool FROM utente WHERE username=? AND passwordhash=SHA1(?)");
                ps.setString(1,user);
                ps.setString(2,passw);
                ResultSet rs = ps.executeQuery();
                if(!rs.next())
                    return null;
                return new Utente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getBoolean(5));
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
}
