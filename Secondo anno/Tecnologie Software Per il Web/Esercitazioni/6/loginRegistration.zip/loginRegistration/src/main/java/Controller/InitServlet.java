package Controller;

import Model.Categoria;
import Model.CategoriaDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.util.List;

@WebServlet(name="MyInit", urlPatterns="/MyInit", loadOnStartup=0)
public class InitServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        CategoriaDAO categoriaDAO = new CategoriaDAO();
        List<Categoria> categorie = categoriaDAO.doRetrieveAll();
        getServletContext().setAttribute("categorie", categorie);
        super.init();
    }
// non è necessario né doGet né doPost. La usiamo solo per inserire le categorie
// nel livello servlet context al caricamento dell’applicazione
// (perché servlet context e non Sessione?)
}
