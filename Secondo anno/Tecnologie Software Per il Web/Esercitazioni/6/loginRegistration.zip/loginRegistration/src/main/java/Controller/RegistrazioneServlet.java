package Controller;

import Model.Utente;
import Model.UtenteDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "RegistrazioneServlet", value = "/RegistrazioneServlet")
public class RegistrazioneServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Utente utente = new Utente();
        String username=request.getParameter("user");
        utente.setUsername(username);
        String password=request.getParameter("pass");
        utente.setPassword(password);
        String email=request.getParameter("email");
        utente.setEmail(email);
        utente.setAdmin_bool(false);
        UtenteDAO.doSave(utente);
        request.getSession().setAttribute("utente", utente);
        response.sendRedirect(".");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
