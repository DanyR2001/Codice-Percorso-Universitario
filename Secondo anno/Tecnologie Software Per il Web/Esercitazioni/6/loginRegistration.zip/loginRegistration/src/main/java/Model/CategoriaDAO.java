package Model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {
    public List<Categoria> doRetrieveAll() {
        List ret=new ArrayList<Categoria>();
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, nome, descrizione FROM Categoria ");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ret.add(new Categoria(rs.getInt(1),rs.getString(2),rs.getString(3)));
            }
            if(ret.size()==0)
                return null;
            return ret;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
