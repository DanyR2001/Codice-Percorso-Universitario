package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProdottoDAO {
    public List<Prodotto> doRetrieveAll() {
        List ret=new ArrayList<Categoria>();
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, nome, descrizione,prezzo FROM Prodotto ");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ret.add(new Prodotto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4)));
            }
            if(ret.size()==0)
                return null;
            return ret;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Prodotto doRetrieveById(int id) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, nome, descrizione,prezzo FROM Prodotto where id=?");
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            return new Prodotto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Prodotto> doRetrieveByCategoria(Categoria find) {
        List ret=new ArrayList<Categoria>();
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT id, nome, descrizione,prezzo FROM Prodotto, ProdottoCategoria where ProdottoCategoria.idCategoria=? and Prodotto.id=ProdottoCategoria.idProdotto");
            ps.setInt(1,find.getId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ret.add(new Prodotto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4)));
            }
            if(ret.size()==0)
                return null;
            return ret;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
