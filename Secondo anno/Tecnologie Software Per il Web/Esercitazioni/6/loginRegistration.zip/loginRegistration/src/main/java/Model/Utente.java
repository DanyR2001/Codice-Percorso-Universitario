package Model;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Utente {
    private int id;
    private String username;
    private String passwordhash;
    private String email;
    private boolean admin_bool;

    public Utente(){};

    public Utente(int id, String username, String email,String passwordhash, boolean admin_bool) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.setPassword(passwordhash);
        this.admin_bool = admin_bool;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isAdmin_bool() {
        return admin_bool;
    }

    public void setAdmin_bool(boolean admin_bool) {
        this.admin_bool = admin_bool;
    }

    public String getPasswordhash() {
        return passwordhash;
    }

    public void setPassword(String password) { // password è inserita dall’utente
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            digest.reset();
            digest.update(password.getBytes(StandardCharsets.UTF_8));
            this.passwordhash = String.format("%040x", new
                    BigInteger(1, digest.digest()));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public void setId(int id) {
        this.id=id;
    }
}
