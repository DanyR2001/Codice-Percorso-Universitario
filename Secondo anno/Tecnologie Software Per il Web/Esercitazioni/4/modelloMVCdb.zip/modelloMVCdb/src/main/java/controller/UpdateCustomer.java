package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Customer;
import model.CustomerDAO;

import java.io.IOException;

@WebServlet(name = "UpdateCustomer", value = "/update-customer")
public class UpdateCustomer extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id= Integer.parseInt(request.getParameter("id"));
        CustomerDAO service=new CustomerDAO();
        Customer x=service.doRetrieveById(id);
        request.setAttribute("customer", x);
        RequestDispatcher dispatcher =
                request.getRequestDispatcher("/WEB-INF/results/update-customer.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}


