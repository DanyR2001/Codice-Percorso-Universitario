package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.CustomerDAO;

import java.io.IOException;
import java.util.Enumeration;

@WebServlet(name = "ShowAll", value = "/ShowAll")
public class ShowAll extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CustomerDAO service=new CustomerDAO();
        request.setAttribute("customers", service.doRetrieveAll());
        Integer par= (Integer) getServletContext().getAttribute("status");
        request.setAttribute("status",par);
        //System.out.println("vaule show all "+par);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/results/showall.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
