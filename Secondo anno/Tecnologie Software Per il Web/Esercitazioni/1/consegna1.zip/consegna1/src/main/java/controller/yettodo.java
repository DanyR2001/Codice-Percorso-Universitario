package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Customer;
import java.io.IOException;


/**
 * Servlet that reads a customer ID and displays
 * information on the account balance of the customer
 * who has that ID.
 * <p>
 * From <a href="http://courses.coreservlets.com/Course-Materials/">the
 * coreservlets.com tutorials on servlets, JSP, Struts, JSF, Ajax, GWT,
 * Spring, Hibernate/JPA, and Java programming</a>.
 */

@WebServlet("/yettodo")
public class yettodo extends HttpServlet {
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String birthdate = request.getParameter("birthdate");
        String città = request.getParameter("città");
        String provincia= request.getParameter("provincia");
        String codice_postale= request.getParameter("codice_postale");
        String via= request.getParameter("via");
        String sesso= request.getParameter("sesso");
        String carta_identità= request.getParameter("carta_identità");
        String mail= request.getParameter("mail");
        String telefono= request.getParameter("telefono");
        String pagina_web= request.getParameter("paginaweb");

        Customer customer = new Customer(fname,lname,birthdate, città, provincia, codice_postale, via, sesso, carta_identità, mail, telefono, pagina_web );
        request.setAttribute("customer", customer);
        String address="showinfo.jsp";

        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}
