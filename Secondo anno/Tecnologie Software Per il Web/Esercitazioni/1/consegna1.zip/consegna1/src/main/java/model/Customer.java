package model;

public class Customer {
    private String nome;
    private  String cognome;
    private  String dataDiNascita;
    private  String città;
    private  String provincia;
    private  String codicePostale;
    private  String via;
    private  String sesso;
    private  String cartaIdentità;
    private  String email;
    private  String telefono;
    private String paginaWeb;

    public Customer(String nome, String cognome, String dataDiNascita, String città, String provincia, String codicePostale, String via, String sesso, String cartaIdentità, String email, String telefono, String paginaWeb) {
        this.nome = nome.substring(0,1).toUpperCase()+nome.substring(1,nome.length()).toLowerCase();
        this.cognome = cognome.substring(0,1).toUpperCase()+cognome.substring(1,cognome.length()).toLowerCase();
        this.dataDiNascita = dataDiNascita;
        this.città = città.substring(0,1).toUpperCase()+città.substring(1,città.length()).toLowerCase();
        this.provincia = provincia.substring(0,1).toUpperCase()+provincia.substring(1,provincia.length()).toLowerCase();
        this.codicePostale = codicePostale;
        this.via = via.substring(0,1).toUpperCase()+via.substring(1,via.length()).toLowerCase();
        this.sesso = sesso;
        this.cartaIdentità = cartaIdentità.toUpperCase().toUpperCase();
        this.email = email.toLowerCase();
        this.telefono = telefono;
        this.paginaWeb = paginaWeb.toLowerCase();
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getDataDiNascita() {
        return dataDiNascita;
    }

    public String getCitta() {
        return città;
    }

    public String getProvincia() {
        return provincia;
    }

    public String getCodicePostale() {
        return codicePostale;
    }

    public String getVia() {
        return via;
    }

    public String getSesso() {
        return sesso;
    }

    public String getCartaIdentita() {
        return cartaIdentità;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getPaginaWeb() {
        return paginaWeb;
    }
}
